from __future__ import annotations
import argparse, csv, json, pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "dags"))
import source_mapping as M
csv.field_size_limit(10_000_000)
def _read(path):
    with open(path, encoding="utf-8-sig", newline="") as fh:
        return list(csv.DictReader(fh))
def _index(rows, key_col):
    return {str(r[key_col]).strip(): r for r in rows}
def build_orders(src_dir, year_min=None, year_max=None):
    fact = _read(src_dir / M.CSV_FILES["fact_sales"])
    cust = _index(_read(src_dir / M.CSV_FILES["dim_customer"]), M.DIM_CUSTOMER["customer_key"])
    prod = _index(_read(src_dir / M.CSV_FILES["dim_product"]), M.DIM_PRODUCT["product_key"])
    geo = _index(_read(src_dir / M.CSV_FILES["dim_geography"]), M.DIM_GEOGRAPHY["geography_key"])
    orders = {}
    for r in fact:
        year = int(r[M.FACT["year"]])
        if year_min and year < year_min: continue
        if year_max and year > year_max: continue
        on = r[M.FACT["order_number"]].strip()
        cid = r[M.FACT["customer_key"]].strip() or M.UNKNOWN_KEY
        gid = r[M.FACT["geography_key"]].strip()
        pid = r[M.FACT["product_key"]].strip()
        mon = M.month_to_num(r[M.FACT["month"]]); day = int(r[M.FACT["day"]])
        order_date = "%04d-%02d-%02d" % (year, mon, day)
        c = cust.get(cid, {}); g = geo.get(gid, {}); p = prod.get(pid, {})
        if on not in orders:
            orders[on] = {"order_number":on,"order_date":order_date,"currency":M.BASE_CURRENCY,
                "customer":{"customer_key":cid,"name":c.get(M.DIM_CUSTOMER["name"]),"segment":c.get(M.DIM_CUSTOMER["segment"]),
                    "gender":c.get(M.DIM_CUSTOMER["gender"]),"age":c.get(M.DIM_CUSTOMER["age"]),
                    "city":c.get(M.DIM_CUSTOMER["city"]),"country":c.get(M.DIM_CUSTOMER["country"])},
                "geography":{"geography_key":gid,"city":g.get(M.DIM_GEOGRAPHY["city"]),"region":g.get(M.DIM_GEOGRAPHY["region"]),"country":g.get(M.DIM_GEOGRAPHY["country"])},
                "items":[]}
        revenue = float(r[M.FACT["revenue"]] or 0); profit = float(r[M.FACT["profit"]] or 0)
        orders[on]["items"].append({"sales_id":r[M.FACT["sales_id"]].strip(),"product_key":pid,
            "product_name":p.get(M.DIM_PRODUCT["product_name"]),"category":p.get(M.DIM_PRODUCT["category"]),
            "brand":p.get(M.DIM_PRODUCT["brand"]),"quantity":int(float(r[M.FACT["quantity"]] or 0)),
            "unit_price":float(r[M.FACT["unit_price"]] or 0),"discount":float(r[M.FACT["discount"]] or 0),
            "sales_amount":revenue,"profit":profit,"total_cost":round(revenue-profit,2)})
    for o in orders.values():
        o["items"].sort(key=lambda it: it["sales_id"])
        for i,it in enumerate(o["items"],start=1): it["line_number"]=i
    return list(orders.values())
def main(argv=None):
    p=argparse.ArgumentParser(); p.add_argument("--src-dir",required=True); p.add_argument("--out",required=True)
    p.add_argument("--year-min",type=int); p.add_argument("--year-max",type=int)
    a=p.parse_args(argv)
    orders=build_orders(pathlib.Path(a.src_dir),a.year_min,a.year_max)
    out=pathlib.Path(a.out); out.parent.mkdir(parents=True,exist_ok=True)
    json.dump(orders, open(out,"w",encoding="utf-8"))
    print("Wrote %d orders / %d line items -> %s" % (len(orders), sum(len(o["items"]) for o in orders), out))
if __name__=="__main__": main()
