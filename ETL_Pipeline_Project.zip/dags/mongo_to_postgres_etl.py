"""Mongo -> Postgres ETL DAG (TaskFlow, LocalExecutor).

Source: nested sales-order documents in MongoDB (built from the Power BI star export).
Target: relational sales star in PostgreSQL (fact_sales + dim_customer/dim_product/
dim_geography/dim_date).

Flow: create_schema -> extract (watermarked) -> transform (flatten) -> load_dimensions
      -> load_facts (+ per-order line sync, audit, advance watermark) -> validate_load.
"""
from __future__ import annotations

import logging
import os
from decimal import Decimal
from pathlib import Path

import pendulum
from airflow.decorators import dag, task

log = logging.getLogger(__name__)

SOURCE_NAME = "raw_orders"
SCHEMA_SQL = Path(os.environ.get("SCHEMA_SQL_PATH", "/opt/airflow/sql/schema.sql"))
_DECIMAL_FIELDS = ("unit_price", "discount", "sales_amount", "total_cost", "profit", "amount_usd")

default_args = {
    "owner": "data-eng",
    "retries": 2,
    "retry_delay": pendulum.duration(minutes=1),
    "execution_timeout": pendulum.duration(minutes=10),
}


def _redact(uri: str) -> str:
    if uri and "@" in uri and "//" in uri:
        scheme, rest = uri.split("//", 1)
        return f"{scheme}//***@{rest.split('@', 1)[1]}"
    return uri or ""


def _mongo_collection():
    from pymongo import MongoClient

    uri = os.environ["MONGO_URI"]
    db_name = os.environ.get("MONGO_DB", "source")
    log.info("Connecting to Mongo %s (db=%s)", _redact(uri), db_name)
    return MongoClient(uri, serverSelectionTimeoutMS=10000)[db_name][SOURCE_NAME]


def _pg_connect():
    import psycopg2

    dsn = os.environ["WAREHOUSE_DSN"]
    log.info("Connecting to warehouse %s", _redact(dsn))
    return psycopg2.connect(dsn)


@dag(
    dag_id="mongo_to_postgres_etl",
    schedule="@daily",
    start_date=pendulum.datetime(2026, 6, 1, tz="UTC"),
    catchup=False,
    max_active_runs=1,
    default_args=default_args,
    tags=["etl", "mongo", "postgres", "sales"],
)
def mongo_to_postgres_etl():

    @task
    def create_schema() -> None:
        ddl = SCHEMA_SQL.read_text(encoding="utf-8")
        with _pg_connect() as conn, conn.cursor() as cur:
            cur.execute(ddl)
        log.info("Schema applied from %s", SCHEMA_SQL)

    @task
    def extract_raw_documents() -> dict:
        """Pull docs with _id greater than the stored cursor; return docs + new cursor."""
        from bson import ObjectId

        with _pg_connect() as conn, conn.cursor() as cur:
            cur.execute("SELECT last_object_id FROM etl_watermark WHERE source_name = %s",
                        (SOURCE_NAME,))
            row = cur.fetchone()
        last_id = row[0] if row else None
        query = {"_id": {"$gt": ObjectId(last_id)}} if last_id else {}
        docs = list(_mongo_collection().find(query).sort("_id", 1))
        log.info("Extracted %d raw documents (cursor > %s)", len(docs), last_id)

        max_object_id = str(docs[-1]["_id"]) if docs else last_id
        clean = []
        for d in docs:
            d = dict(d)
            d.pop("_id", None)
            d["_ingest"] = {"batch_seq": int((d.get("_ingest") or {}).get("batch_seq", 0))}
            clean.append(d)
        return {"docs": clean, "max_object_id": max_object_id}

    @task
    def transform_documents(extracted: dict) -> dict:
        from etl_core import transform

        result = transform(extracted["docs"])
        facts = []
        for f in result.facts:
            f = dict(f)
            for dec in _DECIMAL_FIELDS:
                f[dec] = str(f[dec])
            facts.append(f)
        log.info("Transformed %d orders / %d line items",
                 result.source_orders, result.source_items)
        return {
            "customers": list(result.customers.values()),
            "products": list(result.products.values()),
            "geographies": list(result.geographies.values()),
            "dates": list(result.dates.values()),
            "facts": facts,
            "source_orders": result.source_orders,
            "source_items": result.source_items,
        }

    @task
    def load_dimensions(payload: dict) -> None:
        with _pg_connect() as conn, conn.cursor() as cur:
            for c in payload["customers"]:
                cur.execute(
                    """INSERT INTO dim_customer (customer_key, name, email, segment)
                       VALUES (%(customer_key)s, %(name)s, %(email)s, %(segment)s)
                       ON CONFLICT (customer_key) DO UPDATE SET
                         name=EXCLUDED.name, email=EXCLUDED.email, segment=EXCLUDED.segment""", c)
            for p in payload["products"]:
                cur.execute(
                    """INSERT INTO dim_product (product_key, product_name, category, subcategory)
                       VALUES (%(product_key)s, %(product_name)s, %(category)s, %(subcategory)s)
                       ON CONFLICT (product_key) DO UPDATE SET
                         product_name=EXCLUDED.product_name, category=EXCLUDED.category,
                         subcategory=EXCLUDED.subcategory""", p)
            for g in payload["geographies"]:
                cur.execute(
                    """INSERT INTO dim_geography (geography_key, city, region, country)
                       VALUES (%(geography_key)s, %(city)s, %(region)s, %(country)s)
                       ON CONFLICT (geography_key) DO UPDATE SET
                         city=EXCLUDED.city, region=EXCLUDED.region, country=EXCLUDED.country""", g)
            for d in payload["dates"]:
                cur.execute(
                    """INSERT INTO dim_date (date_key, full_date, year, quarter, month, day)
                       VALUES (%(date_key)s, %(full_date)s, %(year)s, %(quarter)s, %(month)s, %(day)s)
                       ON CONFLICT (date_key) DO NOTHING""", d)
        log.info("Loaded dims: %d customers, %d products, %d geographies, %d dates",
                 len(payload["customers"]), len(payload["products"]),
                 len(payload["geographies"]), len(payload["dates"]))

    @task
    def load_facts(payload: dict, extracted: dict, **context) -> None:
        """Sync line items per changed order, upsert facts, audit, advance cursor."""
        facts = payload["facts"]
        lines_by_order: dict[str, list[int]] = {}
        for f in facts:
            lines_by_order.setdefault(f["order_number"], []).append(f["line_number"])

        run_id = context["run_id"]
        try:
            with _pg_connect() as conn, conn.cursor() as cur:
                for order_number, line_nos in lines_by_order.items():
                    cur.execute(
                        "DELETE FROM fact_sales WHERE order_number=%s AND line_number <> ALL(%s)",
                        (order_number, line_nos))
                for f in facts:
                    params = dict(f)
                    for dec in _DECIMAL_FIELDS:
                        params[dec] = Decimal(f[dec])
                    cur.execute(
                        """INSERT INTO fact_sales (
                               sales_id, order_number, customer_key, product_key, geography_key,
                               order_date_key, line_number, quantity, unit_price, discount,
                               sales_amount, total_cost, profit, currency, amount_usd)
                           VALUES (%(sales_id)s, %(order_number)s, %(customer_key)s, %(product_key)s,
                               %(geography_key)s, %(order_date_key)s, %(line_number)s, %(quantity)s,
                               %(unit_price)s, %(discount)s, %(sales_amount)s, %(total_cost)s,
                               %(profit)s, %(currency)s, %(amount_usd)s)
                           ON CONFLICT (order_number, line_number) DO UPDATE SET
                             sales_id=EXCLUDED.sales_id, customer_key=EXCLUDED.customer_key,
                             product_key=EXCLUDED.product_key, geography_key=EXCLUDED.geography_key,
                             order_date_key=EXCLUDED.order_date_key, quantity=EXCLUDED.quantity,
                             unit_price=EXCLUDED.unit_price, discount=EXCLUDED.discount,
                             sales_amount=EXCLUDED.sales_amount, total_cost=EXCLUDED.total_cost,
                             profit=EXCLUDED.profit, currency=EXCLUDED.currency,
                             amount_usd=EXCLUDED.amount_usd""",
                        params)
                cur.execute(
                    """INSERT INTO etl_run_audit (run_id, source_orders, source_items,
                           loaded_orders, loaded_items, status)
                       VALUES (%s, %s, %s, %s, %s, 'success')
                       ON CONFLICT (run_id) DO UPDATE SET
                         source_orders=EXCLUDED.source_orders, source_items=EXCLUDED.source_items,
                         loaded_orders=EXCLUDED.loaded_orders, loaded_items=EXCLUDED.loaded_items,
                         status='success', error_detail=NULL, run_ts=now()""",
                    (run_id, payload["source_orders"], payload["source_items"],
                     len(lines_by_order), len(facts)))
                if extracted["max_object_id"]:
                    cur.execute(
                        """INSERT INTO etl_watermark (source_name, last_object_id, updated_at)
                           VALUES (%s, %s, now())
                           ON CONFLICT (source_name) DO UPDATE SET
                             last_object_id=EXCLUDED.last_object_id, updated_at=now()""",
                        (SOURCE_NAME, extracted["max_object_id"]))
            log.info("Loaded %d facts across %d orders (run %s)",
                     len(facts), len(lines_by_order), run_id)
        except Exception as exc:
            with _pg_connect() as conn, conn.cursor() as cur:
                cur.execute(
                    """INSERT INTO etl_run_audit (run_id, source_orders, source_items,
                           loaded_orders, loaded_items, status, error_detail)
                       VALUES (%s, %s, %s, 0, 0, 'failed', %s)
                       ON CONFLICT (run_id) DO UPDATE SET status='failed',
                         error_detail=EXCLUDED.error_detail""",
                    (run_id, payload["source_orders"], payload["source_items"], str(exc)))
            raise

    @task
    def validate_load(**context) -> None:
        """Enforce data-quality checks; RAISE on any failure so the run goes red."""
        run_id = context["run_id"]
        problems: list[str] = []
        with _pg_connect() as conn, conn.cursor() as cur:
            cur.execute(
                """SELECT count(*) FROM fact_sales
                   WHERE order_number IS NULL OR product_key IS NULL OR customer_key IS NULL
                      OR quantity IS NULL OR sales_amount IS NULL OR amount_usd IS NULL
                      OR order_date_key IS NULL""")
            if (n := cur.fetchone()[0]):
                problems.append(f"{n} fact rows with null required fields")

            for label, join in {
                "orphan product": "LEFT JOIN dim_product d ON d.product_key=f.product_key WHERE d.product_key IS NULL",
                "orphan customer": "LEFT JOIN dim_customer d ON d.customer_key=f.customer_key WHERE d.customer_key IS NULL",
                "orphan date": "LEFT JOIN dim_date d ON d.date_key=f.order_date_key WHERE d.date_key IS NULL",
                "orphan geography": "LEFT JOIN dim_geography d ON d.geography_key=f.geography_key WHERE f.geography_key IS NOT NULL AND d.geography_key IS NULL",
            }.items():
                cur.execute(f"SELECT count(*) FROM fact_sales f {join}")
                if (n := cur.fetchone()[0]):
                    problems.append(f"{n} {label} rows")

            cur.execute(
                "SELECT source_orders, loaded_orders, source_items, loaded_items "
                "FROM etl_run_audit WHERE run_id=%s", (run_id,))
            audit = cur.fetchone()
            if audit and (audit[0] != audit[1] or audit[2] != audit[3]):
                problems.append(f"audit parity mismatch for run {run_id}: {audit}")

        if problems:
            raise ValueError("Validation failed: " + "; ".join(problems))
        log.info("Validation passed for run %s", run_id)

    schema = create_schema()
    extracted = extract_raw_documents()
    transformed = transform_documents(extracted)
    dims = load_dimensions(transformed)
    facts = load_facts(transformed, extracted)
    validated = validate_load()

    schema >> extracted
    transformed >> dims >> facts >> validated


dag_instance = mongo_to_postgres_etl()
