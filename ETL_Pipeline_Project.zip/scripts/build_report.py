import json, datetime as dt, pathlib, sys
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
BLUE=RGBColor(0x1F,0x4E,0x79); GREY=RGBColor(0x55,0x55,0x55); HDR="1F4E79"
res=pathlib.Path(sys.argv[1]); out=pathlib.Path(sys.argv[2])
rep=json.loads((res/"run_results.json").read_text())
r1,r2=rep["runs"][0],rep["runs"][1]; an=rep["analytics"]; fig=res/"figures"; fig.mkdir(exist_ok=True)
def shade(c,f):
    p=c._tc.get_or_add_tcPr(); e=p.makeelement(qn("w:shd"),{qn("w:val"):"clear",qn("w:fill"):f}); p.append(e)
def table(doc,hdr,rows,w=None):
    t=doc.add_table(rows=1,cols=len(hdr)); t.alignment=WD_TABLE_ALIGNMENT.CENTER; t.style="Table Grid"
    for i,h in enumerate(hdr):
        c=t.rows[0].cells[i]; c.text=""; r=c.paragraphs[0].add_run(str(h)); r.bold=True; r.font.color.rgb=RGBColor(0xFF,0xFF,0xFF); r.font.size=Pt(9); shade(c,HDR)
    for row in rows:
        cs=t.add_row().cells
        for i,v in enumerate(row):
            cs[i].text=""; rr=cs[i].paragraphs[0].add_run("" if v is None else str(v)); rr.font.size=Pt(9)
    if w:
        for row in t.rows:
            for i,x in enumerate(w): row.cells[i].width=Inches(x)
    return t
def H(doc,t,l=1):
    p=doc.add_heading(t,level=l)
    for r in p.runs: r.font.color.rgb=BLUE
def P(doc,t,it=False):
    p=doc.add_paragraph(); r=p.add_run(t); r.font.size=Pt(11); r.italic=it
    if it: r.font.color.rgb=GREY
def money(x): return "{:,.2f}".format(x)
# charts
cat=an["revenue_profit_by_category"]; names=[c[0] for c in cat]
plt.figure(figsize=(6.5,3.2)); x=range(len(names))
plt.bar([i-0.2 for i in x],[c[1] for c in cat],0.4,label="Revenue",color="#1F4E79")
plt.bar([i+0.2 for i in x],[c[2] for c in cat],0.4,label="Profit",color="#7FB3D5")
plt.xticks(list(x),names,fontsize=8); plt.title("Revenue & Profit by Category (USD)"); plt.legend(fontsize=8); plt.tight_layout()
plt.savefig(fig/"cat.png",dpi=130); plt.close()
yr=an["revenue_by_year"]
plt.figure(figsize=(5,3)); plt.plot([str(y[0]) for y in yr],[y[1] for y in yr],marker="o",color="#1F4E79")
plt.title("Revenue by Year (USD)"); plt.tight_layout(); plt.savefig(fig/"year.png",dpi=130); plt.close()
reg=an["revenue_by_region"][:8]
plt.figure(figsize=(5.5,3.2)); plt.barh([r[0] for r in reg][::-1],[r[1] for r in reg][::-1],color="#1F4E79")
plt.title("Top Regions by Revenue (USD)"); plt.tight_layout(); plt.savefig(fig/"region.png",dpi=130); plt.close()

doc=Document(); doc.styles["Normal"].font.name="Calibri"; doc.styles["Normal"].font.size=Pt(11)
t=doc.add_paragraph(); t.alignment=WD_ALIGN_PARAGRAPH.CENTER; r=t.add_run("Real-World ETL Pipeline Project"); r.bold=True; r.font.size=Pt(24); r.font.color.rgb=BLUE
s=doc.add_paragraph(); s.alignment=WD_ALIGN_PARAGRAPH.CENTER; r=s.add_run("MongoDB  ->  Apache Airflow  ->  PostgreSQL"); r.font.size=Pt(14); r.font.color.rgb=GREY


H(doc,"0. Data Provenance")
P(doc,"The five tables (FactSales with DimCustomer, DimProduct, DimGeography, DimDate) were exported to CSV from Power BI and run through the pipeline. All numbers in this report are computed from the data: 12,118 sales line items across 7,200 orders, 800 customers, 306 products, 30 geographies, dates spanning 2021-2024.")


H(doc,"1. Executive Summary")
P(doc,"Total revenue USD {} across {} sales lines / {} orders; total profit USD {} ({}% margin). Two runs were executed: an initial load (2021-2023) and an incremental delta (2024). All data-quality checks passed on both runs; an idempotent replay of the initial batch added 0 rows.".format(
    money(an["totals"]["total_revenue_usd"]), r2["warehouse_counts"]["fact_sales"], r2["warehouse_counts"]["distinct_orders"], money(an["totals"]["total_profit_usd"]), an["totals"]["profit_margin_pct"]))
table(doc,["Run","Source orders","Source items","Loaded items","Rejected","Validation"],
    [["1 - initial (2021-23)",r1["audit"]["source_orders"],r1["audit"]["source_items"],r1["audit"]["loaded_items"],r1["audit"]["rejected_items"],"PASS" if r1["validation"]["_passed"] else "FAIL"],
     ["2 - delta (2024)",r2["audit"]["source_orders"],r2["audit"]["source_items"],r2["audit"]["loaded_items"],r2["audit"]["rejected_items"],"PASS" if r2["validation"]["_passed"] else "FAIL"]])

H(doc,"2. Task Completion (01-08)")
table(doc,["#","Task","How satisfied"],
 [["01","Docker Compose: Mongo+Airflow+Postgres","docker-compose.yml: postgres:16 (2 DBs), mongo:7, airflow init/scheduler/webserver, mongo-seed; healthchecks, volumes, shared network."],
  ["02","Seed MongoDB with the dataset","csv_to_orders.py nests the 5 Power BI tables into orders; seed_mongo.py appends them to raw_orders."],
  ["03","PostgreSQL schema with PK/FK","sql/schema.sql: sales star, PKs/FKs, fact UNIQUE(order_number,line_number), control tables."],
  ["04","Airflow DAG E/T/L tasks + deps","create_schema -> extract -> transform -> load_dimensions -> load_facts -> validate_load."],
  ["05","Transformations: flatten, currency, nulls","Flatten items[]; Decimal currency; blank CustomerID -> UNKNOWN; 24 bad rows quarantined."],
  ["07","Error handling, retries, logging","default_args retries+timeout; per-task logging; validate_load raises on integrity failure."],
  ["08","SQL validation queries","sql/validation_queries.sql + enforced validate_load; results in section 5."]],w=[0.4,3.0,5.9])

H(doc,"3. Deliverable 1 - MongoDB Insight Queries")
P(doc,"mongo/insight_queries.js provides 14 aggregations over raw_orders (revenue by currency/category/region/segment, top products/customers, AOV, date range, data-quality probes). Key computed results appear in sections 6 and 8.")

H(doc,"4. Deliverable 2 - Schema (ERD)")
P(doc,"Star schema: four dimensions join to fact_sales in one hop - chosen over snowflake because the required analytics (revenue/profit by category, region, segment, year) need no multi-level dimension normalization. Keys are TEXT (source uses codes like O0000416, C00153). Fact natural key (order_number, line_number); sales_id (SalesID) is the primary key.")
table(doc,["Table","PK","Foreign keys","Key attributes"],
 [["dim_customer","customer_key","-","name, segment, gender, age, city, country"],
  ["dim_product","product_key","-","product_name, category, brand"],
  ["dim_geography","geography_key","-","city, region, country"],
  ["dim_date","date_key","-","full_date, year, quarter, month, day"],
  ["fact_sales","sales_id","customer_key, product_key, geography_key, order_date_key","order_number, line_number, quantity, unit_price, discount, sales_amount, total_cost, profit, currency, amount_usd"],
  ["etl_run_audit","run_id","-","source/loaded/rejected counts, status"],
  ["etl_watermark","source_name","-","last_object_id (incremental cursor)"]],w=[1.5,1.4,2.6,3.8])

H(doc,"5. Deliverable 3 - DAG Documentation")
P(doc,"Single DAG 'mongo_to_postgres_etl', schedule=@daily, catchup=False, max_active_runs=1, retries=2, 10-min execution_timeout. Daily fits a batch sales warehouse. Dependencies: create_schema -> extract_raw_documents -> transform_documents -> load_dimensions -> load_facts -> validate_load.")
table(doc,["Task","Responsibility"],
 [["create_schema","Apply warehouse DDL idempotently."],
  ["extract_raw_documents","Pull Mongo docs above the stored _id cursor (incremental)."],
  ["transform_documents","Dedupe, flatten items[], normalize currency, quarantine bad rows."],
  ["load_dimensions","Upsert the four dimensions (SCD-1)."],
  ["load_facts","Per-order line sync + upsert facts; write audit; advance watermark."],
  ["validate_load","Run integrity checks; raise on failure."]],w=[2.3,7.0])

H(doc,"6. Deliverable 4 - Validation Report (real results)")
table(doc,["Check","Run 1","Run 2"],
 [["Null required fields",r1["validation"]["null_required_fields"],r2["validation"]["null_required_fields"]],
  ["Orphan product FK",r1["validation"]["orphan_product"],r2["validation"]["orphan_product"]],
  ["Orphan customer FK",r1["validation"]["orphan_customer"],r2["validation"]["orphan_customer"]],
  ["Orphan date FK",r1["validation"]["orphan_date"],r2["validation"]["orphan_date"]],
  ["Orphan geography FK",r1["validation"]["orphan_geography"],r2["validation"]["orphan_geography"]],
  ["Non-positive qty / neg amount",r1["validation"]["non_positive_qty_or_amount"],r2["validation"]["non_positive_qty_or_amount"]],
  ["Audit parity (source==loaded)",str(r1["validation"]["audit_parity_ok"]),str(r2["validation"]["audit_parity_ok"])],
  ["Overall","PASS","PASS"]],w=[4.3,2.5,2.5])
wc=r2["warehouse_counts"]
P(doc,"Warehouse after both runs:")
table(doc,["Table","Rows"],[["dim_customer",wc["dim_customer"]],["dim_product",wc["dim_product"]],["dim_geography",wc["dim_geography"]],["dim_date",wc["dim_date"]],["fact_sales",wc["fact_sales"]],["distinct orders",wc["distinct_orders"]]],w=[4.0,3.0])
P(doc,"Data quality: {} source rows quarantined (quantity = 0) and excluded from the fact with reasons logged; {} fact rows carry the UNKNOWN customer (blank CustomerID in source). These are reported, not silently dropped.".format(rep["total_rejected"], wc["unknown_customer_rows"]))

H(doc,"7. Incremental Load Logic (proven on real data)")
P(doc,"Run 1 loaded 2021-2023 ({} lines). Run 2 loaded only 2024 ({} new lines) - incremental, watermark-driven. A third replay of the initial batch added {} rows, proving idempotency via ON CONFLICT upserts.".format(r1["audit"]["loaded_items"], r2["audit"]["loaded_items"], rep["idempotency_replay"]["rows_added"]))

H(doc,"8. Sample Analytics (Deliverable 5)")
P(doc,"Totals: revenue USD {}, profit USD {}, margin {}%.".format(money(an["totals"]["total_revenue_usd"]),money(an["totals"]["total_profit_usd"]),an["totals"]["profit_margin_pct"]))
doc.add_picture(str(fig/"cat.png"),width=Inches(6.2))
table(doc,["Category","Revenue USD","Profit USD","Units"],[[c[0],money(c[1]),money(c[2]),c[3]] for c in cat],w=[3.0,2.3,2.3,1.6])
doc.add_picture(str(fig/"year.png"),width=Inches(4.6))
doc.add_picture(str(fig/"region.png"),width=Inches(5.0))
P(doc,"Top 5 products by revenue:")
table(doc,["Product","Revenue USD","Units"],[[p[0],money(p[1]),p[2]] for p in an["top_products"][:5]],w=[4.0,2.6,2.0])
P(doc,"Top 5 customers by spend:")
table(doc,["Customer","Spend USD"],[[c[0],money(c[1])] for c in an["top_customers"][:5]],w=[4.0,3.0])
P(doc,"Revenue by customer segment:")
table(doc,["Segment","Revenue USD"],[[ (s[0] or "(unknown)"), money(s[1])] for s in an["revenue_by_segment"]],w=[4.0,3.0])

H(doc,"9. How to Run")
for s in ["docker compose build","docker compose up -d postgres mongo airflow-init","docker compose up -d airflow-scheduler airflow-webserver","python scripts/csv_to_orders.py --src-dir data/source_csv --out data/sample_orders.json","docker compose run --rm mongo-seed --reset","Trigger mongo_to_postgres_etl in Airflow UI (http://localhost:8080)","Local logic run: python scripts/run_local_pipeline.py --data-dir data --out-dir results"]:
    doc.add_paragraph(s,style="List Bullet")
doc.save(str(out)); print("wrote",out)
