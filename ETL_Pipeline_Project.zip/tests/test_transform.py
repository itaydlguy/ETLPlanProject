"""Unit tests for the sales-star transform (stdlib only; no Airflow/Mongo/Postgres).

Run:  python -m unittest tests/test_transform.py   (or pytest tests/test_transform.py)
"""
import json
import pathlib
import sys
import unittest
from decimal import Decimal

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "dags"))
import etl_core  # noqa: E402

DATA = ROOT / "data"


def _order(order_number="O1", batch_seq=1, items=None, customer=None, **over):
    doc = {
        "order_number": order_number, "order_date": "2023-06-15", "currency": "USD",
        "customer": customer if customer is not None else
            {"customer_key": "C1", "name": "Acme", "segment": "Consumer", "city": "Berlin", "country": "DE"},
        "geography": {"geography_key": "G1", "city": "Berlin", "region": "EU", "country": "DE"},
        "items": items if items is not None else [
            {"sales_id": "S1", "line_number": 1, "product_key": "P1", "product_name": "Chair",
             "category": "Furniture", "brand": "Aster", "quantity": 2, "unit_price": 10.0,
             "sales_amount": 20.0, "profit": 8.0, "total_cost": 12.0}],
        "_ingest": {"batch_seq": batch_seq},
    }
    doc.update(over)
    return doc


class TestCurrency(unittest.TestCase):
    def test_usd(self):
        self.assertEqual(etl_core.to_usd(Decimal("20.00"), "USD"), Decimal("20.00"))

    def test_eur(self):
        self.assertEqual(etl_core.to_usd(Decimal("100.00"), "EUR"), Decimal("108.00"))

    def test_unknown_currency_raises(self):
        with self.assertRaises(ValueError):
            etl_core.to_usd(Decimal("1"), "XYZ")


class TestTransform(unittest.TestCase):
    def test_basic_flatten_profit(self):
        res = etl_core.transform([_order()])
        self.assertEqual(res.source_orders, 1)
        self.assertEqual(res.source_items, 1)
        f = res.facts[0]
        self.assertEqual(f["profit"], Decimal("8.00"))
        self.assertEqual(f["amount_usd"], Decimal("20.00"))
        self.assertEqual(res.dates[20230615]["quarter"], 2)

    def test_blank_customer_maps_to_unknown(self):
        res = etl_core.transform([_order(customer={"customer_key": ""})])
        self.assertEqual(res.facts[0]["customer_key"], "UNKNOWN")
        self.assertIn("UNKNOWN", res.customers)

    def test_quarantine_non_positive_quantity(self):
        bad = _order(items=[{"sales_id": "S9", "product_key": "P1", "quantity": 0,
                             "sales_amount": 5, "profit": 1}])
        res = etl_core.transform([bad])
        self.assertEqual(len(res.facts), 0)
        self.assertEqual(len(res.rejects), 1)
        self.assertEqual(res.rejects[0]["reason"], "non-positive quantity")

    def test_quarantine_missing_required_field(self):
        bad = _order(items=[{"sales_id": "S9", "product_key": "P1", "quantity": 1}])  # no sales_amount
        res = etl_core.transform([bad])
        self.assertEqual(len(res.facts), 0)
        self.assertTrue(res.rejects[0]["reason"].startswith("missing"))

    def test_dedupe_keeps_latest_batch(self):
        v1 = _order("O9", batch_seq=1, items=[{"sales_id": "S", "product_key": "P1",
                    "quantity": 1, "sales_amount": 10, "profit": 2}])
        v2 = _order("O9", batch_seq=2, items=[{"sales_id": "S", "product_key": "P1",
                    "quantity": 5, "sales_amount": 50, "profit": 10}])
        res = etl_core.transform([v1, v2])
        self.assertEqual(res.source_orders, 1)
        self.assertEqual(res.facts[0]["quantity"], 5)


class TestBundledDataset(unittest.TestCase):
    def _load(self, name):
        p = DATA / name
        if not p.exists():
            self.skipTest(name + " not generated")
        return json.loads(p.read_text(encoding="utf-8"))

    def test_sample_orders_consistent(self):
        res = etl_core.transform(self._load("sample_orders.json"))
        self.assertEqual(res.source_items, len(res.facts))
        for f in res.facts[:200]:
            self.assertIsNotNone(f["amount_usd"])
            self.assertEqual(f["profit"], f["sales_amount"] - f["total_cost"])


if __name__ == "__main__":
    unittest.main()
