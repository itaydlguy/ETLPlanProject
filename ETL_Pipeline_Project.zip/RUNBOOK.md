# Runbook — run the real stack & live demo (Tasks 01 & Deliverable 5)

This is the one part that must run on a machine with **Docker Desktop** (Windows/Mac/Linux).
Everything is already in this folder; follow top to bottom. Total time ~10–15 min.

## 0. Prerequisites
- Docker Desktop installed and running.
- This `etl_pipeline_project/` folder on disk.
- Your 5 CSVs are already in `data/source_csv/` (`fact_sales.csv`, `DimCustomer.csv`,
  `DimProduct.csv`, `DimGeography.csv`, `DimDate.csv`).

## 1. Build the nested source from the CSVs
```bash
python scripts/csv_to_orders.py --src-dir data/source_csv --out data/sample_orders.json
python scripts/csv_to_orders.py --src-dir data/source_csv --out data/orders_initial.json --year-max 2023
python scripts/csv_to_orders.py --src-dir data/source_csv --out data/orders_delta.json   --year-min 2024
```
Expect: `Wrote 7200 orders / 12118 line items` (full), 5428/9096 (initial), 1772/3022 (delta).

## 2. Configure env
```bash
cp .env.example .env
# Linux/Mac: set your uid so logs aren't root-owned
echo "AIRFLOW_UID=$(id -u)" >> .env        # Windows: leave AIRFLOW_UID=50000
```

## 3. Bring up the stack
```bash
docker compose build
docker compose up -d postgres mongo airflow-init
docker compose up -d airflow-scheduler airflow-webserver
docker compose ps      # wait until postgres & mongo are "healthy"
```

## 4. Seed MongoDB (Task 02 — Extract source visible)
```bash
docker compose run --rm mongo-seed --reset
```

## 5. Trigger the DAG (Deliverable 5 — live)
- Open http://localhost:8080  (login `admin` / `admin`).
- Un-pause `mongo_to_postgres_etl`, click **Trigger DAG**.
- Watch tasks go green: `create_schema → extract_raw_documents → transform_documents →
  load_dimensions → load_facts → validate_load`. Open each task's **Logs** to narrate.

CLI alternative:
```bash
docker compose exec airflow-scheduler airflow dags trigger mongo_to_postgres_etl
```

## 6. Validation SQL (Deliverable 4 — against real Postgres)
```bash
docker compose exec postgres psql -U airflow -d warehouse -f /sql/validation_queries.sql
```
Expect: every data-quality check returns **0**; audit parity row shows source == loaded.

## 7. MongoDB insight queries (Deliverable 1 — against real Mongo)
```bash
docker compose exec mongo mongosh -u root -p example --authenticationDatabase admin \
  "mongodb://localhost:27017/source" /docker-entrypoint-initdb.d/insight_queries.js
# (or copy mongo/insight_queries.js in and run: load('/insight_queries.js'))
```

## 8. Sample analytics query (Deliverable 5 — close the demo)
```bash
docker compose exec postgres psql -U airflow -d warehouse -c \
"SELECT p.category, round(sum(f.amount_usd),2) revenue, round(sum(f.profit),2) profit
 FROM fact_sales f JOIN dim_product p ON p.product_key=f.product_key
 GROUP BY p.category ORDER BY revenue DESC;"
```

## Expected results (match this report / results/)
- Initial load: 9,076 fact rows; delta adds 2024 → **12,094 fact rows, 7,193 orders**.
- 24 rows quarantined (quantity = 0); 71 rows with UNKNOWN customer.
- Totals: revenue ≈ USD 23,541,083.85, profit ≈ USD 8,202,065.08 (34.84% margin).

## Common first-run fixes
- **Webserver not loading:** wait 30–60s after `up`; check `docker compose logs airflow-webserver`.
- **Port 8080/5432/27017 in use:** stop the conflicting service or change the host port in
  `docker-compose.yml` `ports:`.
- **`AIRFLOW_UID` warning (Linux):** ensure step 2 set it; otherwise logs may be root-owned.
- **Build can't fetch constraints:** needs internet at build time; or vendor the constraints
  file and `COPY` it in the Dockerfile.
- **Mongo seed can't find file:** confirm `SOURCE_DATASET_PATH=/opt/airflow/data/sample_orders.json`
  in `.env` and that `./data` is mounted (it is, in `docker-compose.yml`).
- **DAG not visible:** it's paused by default; un-pause it in the UI.

If any step errors, copy the message to me and I'll pinpoint the fix.
