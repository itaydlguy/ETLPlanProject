-- Post-load validation for the sales star. validate_load runs these in-task and RAISES on
-- failure; kept here for manual runs:
--   docker compose exec postgres psql -U airflow -d warehouse -f /sql/validation_queries.sql

-- 1. Latest-run audit parity: source == loaded at both grains (orders and line items).
SELECT run_id, source_orders, loaded_orders, source_items, loaded_items,
       (source_orders = loaded_orders AND source_items = loaded_items) AS ok
FROM etl_run_audit ORDER BY run_ts DESC LIMIT 1;

-- 2. Grain check: distinct orders vs total fact rows (rows should be >= orders).
SELECT count(DISTINCT order_number) AS orders,
       count(*)                     AS line_items
FROM fact_sales;

-- 3. Required-field null checks (expect 0).
SELECT 'fact null required field' AS check, count(*) AS bad_rows
FROM fact_sales
WHERE order_number IS NULL OR product_key IS NULL OR customer_key IS NULL
   OR quantity IS NULL OR sales_amount IS NULL OR amount_usd IS NULL OR order_date_key IS NULL;

-- 4-7. Orphaned FK checks (expect 0).
SELECT 'orphan product' AS check, count(*) AS bad_rows
FROM fact_sales f LEFT JOIN dim_product d ON d.product_key=f.product_key
WHERE d.product_key IS NULL;

SELECT 'orphan customer' AS check, count(*) AS bad_rows
FROM fact_sales f LEFT JOIN dim_customer d ON d.customer_key=f.customer_key
WHERE d.customer_key IS NULL;

SELECT 'orphan date' AS check, count(*) AS bad_rows
FROM fact_sales f LEFT JOIN dim_date d ON d.date_key=f.order_date_key
WHERE d.date_key IS NULL;

SELECT 'orphan geography' AS check, count(*) AS bad_rows
FROM fact_sales f LEFT JOIN dim_geography d ON d.geography_key=f.geography_key
WHERE f.geography_key IS NOT NULL AND d.geography_key IS NULL;

-- 8. Data-quality guard: non-positive quantity / negative amounts (expect 0).
SELECT 'non-positive qty/amount' AS check, count(*) AS bad_rows
FROM fact_sales WHERE quantity <= 0 OR sales_amount < 0;

-- ---- Sample analytics (Deliverable 5) ----------------------------------------------
-- 9. Revenue + profit by product category (normalized USD).
SELECT p.category,
       round(sum(f.amount_usd), 2) AS revenue_usd,
       round(sum(f.profit), 2)     AS profit,
       sum(f.quantity)             AS units
FROM fact_sales f JOIN dim_product p ON p.product_key=f.product_key
GROUP BY p.category ORDER BY revenue_usd DESC;

-- 10. Revenue by region and customer segment.
SELECT g.region, c.segment, round(sum(f.amount_usd), 2) AS revenue_usd
FROM fact_sales f
JOIN dim_geography g ON g.geography_key=f.geography_key
JOIN dim_customer c ON c.customer_key=f.customer_key
GROUP BY g.region, c.segment ORDER BY revenue_usd DESC;
