"""Pure transformation logic: nested sales orders -> relational sales star.

Standard library only (no Airflow / pymongo / psycopg2) so it is unit-testable without
infrastructure. The Mongo source stores nested order documents (order header + items[]);
this module FLATTENS them into dimension records + a fact_sales line-item grain.

Real-world data quality: row-level problems (non-positive quantity, negative amount,
missing required field) are QUARANTINED into result.rejects with a reason and excluded
from the fact, rather than crashing the whole run. Structural problems (no order_number)
still raise. Blank CustomerID maps to the UNKNOWN dimension member.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from decimal import ROUND_HALF_UP, Decimal

from source_mapping import BASE_CURRENCY, FX_RATES, UNKNOWN_KEY

_CENTS = Decimal("0.01")
REQUIRED_ITEM_FIELDS = ("product_key", "quantity", "sales_amount")


@dataclass
class TransformResult:
    customers: dict = field(default_factory=dict)
    products: dict = field(default_factory=dict)
    geographies: dict = field(default_factory=dict)
    dates: dict = field(default_factory=dict)
    facts: list = field(default_factory=list)
    rejects: list = field(default_factory=list)
    source_orders: int = 0
    source_items: int = 0


def to_usd(sales_amount: Decimal, currency: str, rates=None) -> Decimal:
    rates = rates or FX_RATES
    if currency not in rates:
        raise ValueError("Unknown currency code: " + repr(currency))
    return (sales_amount * rates[currency]).quantize(_CENTS, rounding=ROUND_HALF_UP)


def parse_date(order_date: str):
    if not order_date:
        raise ValueError("order_date is required")
    d = dt.datetime.strptime(order_date[:10], "%Y-%m-%d").date()
    return d.year * 10000 + d.month * 100 + d.day, d


def _key(value, label: str) -> str:
    if value is None:
        raise ValueError(label + " is required")
    s = str(value).strip()
    if not s:
        raise ValueError(label + " must not be blank")
    return s


def dedupe_latest(documents):
    latest = {}
    for doc in documents:
        on = _key(doc.get("order_number"), "order_number")
        seq = int((doc.get("_ingest") or {}).get("batch_seq", 0))
        prev = latest.get(on)
        if prev is None or seq >= int((prev.get("_ingest") or {}).get("batch_seq", 0)):
            latest[on] = doc
    return list(latest.values())


def transform(documents, rates=None) -> TransformResult:
    result = TransformResult()
    for doc in dedupe_latest(documents):
        order_number = _key(doc.get("order_number"), "order_number")
        currency = (doc.get("currency") or BASE_CURRENCY).strip().upper()
        date_key, full_date = parse_date(doc.get("order_date"))
        cust = doc.get("customer") or {}
        ckey = (str(cust.get("customer_key")).strip()
                if cust.get("customer_key") not in (None, "") else UNKNOWN_KEY)
        geo = doc.get("geography") or {}
        gkey = _key(geo.get("geography_key"), "geography_key") if geo.get("geography_key") else None

        valid_in_order = 0
        for idx, item in enumerate(doc.get("items") or []):
            line_number = int(item.get("line_number", idx + 1))
            sid = item.get("sales_id", order_number + "-" + str(line_number))
            # row-level data-quality gate: quarantine bad rows, do not crash
            bad = None
            for f in REQUIRED_ITEM_FIELDS:
                if item.get(f) is None:
                    bad = "missing " + f
                    break
            if bad is None and int(item["quantity"]) <= 0:
                bad = "non-positive quantity"
            if bad is None and Decimal(str(item["sales_amount"])) < 0:
                bad = "negative sales_amount"
            if bad:
                result.rejects.append({"sales_id": sid, "order_number": order_number, "reason": bad})
                continue

            product_key = _key(item.get("product_key"), "product_key")
            quantity = int(item["quantity"])
            unit_price = Decimal(str(item.get("unit_price", 0)))
            discount = Decimal(str(item.get("discount", 0)))
            sales_amount = Decimal(str(item["sales_amount"]))
            total_cost = Decimal(str(item.get("total_cost", 0)))
            profit = (Decimal(str(item["profit"])) if item.get("profit") is not None
                      else (sales_amount - total_cost)).quantize(_CENTS, rounding=ROUND_HALF_UP)

            result.products[product_key] = {
                "product_key": product_key, "product_name": item.get("product_name"),
                "category": item.get("category"), "brand": item.get("brand")}
            result.facts.append({
                "sales_id": _key(sid, "sales_id"), "order_number": order_number,
                "customer_key": ckey, "product_key": product_key, "geography_key": gkey,
                "order_date_key": date_key, "line_number": line_number, "quantity": quantity,
                "unit_price": unit_price, "discount": discount, "sales_amount": sales_amount,
                "total_cost": total_cost, "profit": profit, "currency": currency,
                "amount_usd": to_usd(sales_amount, currency, rates)})
            result.source_items += 1
            valid_in_order += 1

        if valid_in_order == 0:
            continue
        result.source_orders += 1
        result.customers[ckey] = {
            "customer_key": ckey, "name": cust.get("name"), "segment": cust.get("segment"),
            "gender": cust.get("gender"),
            "age": int(cust["age"]) if str(cust.get("age", "")).strip().isdigit() else None,
            "city": cust.get("city"), "country": cust.get("country")}
        if gkey is not None:
            result.geographies[gkey] = {
                "geography_key": gkey, "city": geo.get("city"),
                "region": geo.get("region"), "country": geo.get("country")}
        result.dates[date_key] = {
            "date_key": date_key, "full_date": full_date.isoformat(), "year": full_date.year,
            "quarter": (full_date.month - 1) // 3 + 1, "month": full_date.month, "day": full_date.day}
    return result
