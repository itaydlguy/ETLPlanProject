# Validation Report (real Power BI data)

Results of executing the pipeline on the real exported dataset
(`scripts/run_local_pipeline.py`; raw output in `results/run_results.json`).

## Source

12,118 sales lines / 7,200 orders, 800 customers, 306 products, 30 geographies, 2021–2024.
Grain: Mongo = one document per order with nested `items[]`; warehouse = one `fact_sales`
row per `SalesID`. Validation is done at matching grains.

## Per-run audit (source vs target)

| Run | Source orders | Source items | Loaded items | Rejected (qty=0) | Parity |
|-----|---------------|--------------|--------------|------------------|--------|
| 1 — initial (2021–23) | 5,421 | 9,076 | 9,076 | 20 | ✅ |
| 2 — delta (2024) | 1,772 | 3,018 | 3,018 | 4 | ✅ |

## Warehouse after both runs

| Table | Rows |
|-------|------|
| dim_customer | 801 (incl. UNKNOWN) |
| dim_product | 306 |
| dim_geography | 29 |
| dim_date | 1,456 |
| fact_sales | 12,094 |
| distinct orders | 7,193 |

## Data-quality checks (both runs = 0 / pass)

| Check | Result |
|-------|--------|
| Null required fields in fact | 0 |
| Orphan product FK | 0 |
| Orphan customer FK | 0 |
| Orphan date FK | 0 |
| Orphan geography FK | 0 |
| Non-positive qty / negative amount in fact | 0 |
| Audit parity (source == loaded) | true |

## Data-quality handling (reported, not hidden)

- **24 source rows quarantined** (quantity = 0), excluded from the fact with reasons logged
  (`results/run_results.json` → `reject_samples`).
- **71 fact rows** carry the `UNKNOWN` customer (blank `CustomerID` in source).
- 7 single-line orders were fully quarantined → distinct orders 7,200 → 7,193.

## Incremental & idempotency

Run 2 loaded only 2024 (incremental). A replay of the initial batch added **0 rows**
(`idempotency_replay.rows_added = 0`), proving idempotent upserts.

## Totals (sanity analytics)

Revenue USD 23,541,083.85; profit USD 8,202,065.08; margin 34.84%.
