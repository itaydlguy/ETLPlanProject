# MongoDB → Airflow → PostgreSQL ETL (Power BI sales dataset)

ETL pipeline for the project's Power BI dataset (`PowerBI_Project.pbix`). The Power BI model
is a sales star — `FactSales` + `DimCustomer`, `DimProduct`, `DimGeography`, `DimDate`. Its
five tables (exported to CSV) are reshaped into **nested order documents** in MongoDB, an
**Airflow** DAG flattens and normalizes them, and the result lands in a clean **PostgreSQL**
sales star — with incremental (watermarked) extraction, idempotent upserts, currency
normalization, data-quality quarantine, and an enforced validation gate.

## Real-data run results

The pipeline was executed on the real exported data (`scripts/run_local_pipeline.py`, results
in `results/`). Source: **12,118 sales lines / 7,200 orders, 800 customers, 306 products,
30 geographies, 2021–2024**.

| Run | Source orders | Source items | Loaded items | Rejected | Validation |
|-----|---------------|--------------|--------------|----------|------------|
| 1 — initial (2021–23) | 5,421 | 9,076 | 9,076 | 20 | PASS |
| 2 — delta (2024) | 1,772 | 3,018 | 3,018 | 4 | PASS |

After both runs: **12,094 fact rows**, 7,193 distinct orders, 801 customers (incl. `UNKNOWN`),
306 products, 29 geographies, 1,456 dates. A third replay of the initial batch added **0 rows**
(idempotent). Totals: **revenue USD 23,541,083.85, profit USD 8,202,065.08 (34.84% margin)**.

Data quality handled, not hidden: **24 source rows quarantined** (quantity = 0) and logged;
**71 fact rows carry the `UNKNOWN` customer** (blank `CustomerID` in source).

## Stack

| Component | Image (pinned) | Role |
|-----------|----------------|------|
| PostgreSQL | `postgres:16` | `airflow` (metadata) + `warehouse` (target) DBs |
| MongoDB | `mongo:7` | source landing zone (`raw_orders`, nested orders) |
| Airflow | `apache/airflow:2.10.5-python3.12` (extended) | `LocalExecutor` |

Diagrams: [`docs/diagrams.md`](docs/diagrams.md). Report: `PROJECT_REPORT.docx`.

## Source data

Export the five tables from Power BI to CSV (DAX Studio → Export Data, or Power BI table
visual → Export) into `data/source_csv/` as `fact_sales.csv`, `DimCustomer.csv`,
`DimProduct.csv`, `DimGeography.csv`, `DimDate.csv`. Real column names are mapped in
[`dags/source_mapping.py`](dags/source_mapping.py) — the only file to touch if headers differ.
Then build the nested orders:

```bash
python scripts/csv_to_orders.py --src-dir data/source_csv --out data/sample_orders.json
# incremental split used for the demo:
python scripts/csv_to_orders.py --src-dir data/source_csv --out data/orders_initial.json --year-max 2023
python scripts/csv_to_orders.py --src-dir data/source_csv --out data/orders_delta.json   --year-min 2024
```

## Quick start (Docker)

```bash
cp .env.example .env          # set AIRFLOW_UID (id -u) and passwords
docker compose build
docker compose up -d postgres mongo airflow-init
docker compose up -d airflow-scheduler airflow-webserver
docker compose run --rm mongo-seed --reset
# open http://localhost:8080 (admin/admin), trigger `mongo_to_postgres_etl`
```

Run the ETL logic without Docker (what produced `results/`):

```bash
python scripts/run_local_pipeline.py --data-dir data --out-dir results
```

## Data model (sales star)

`dim_customer`, `dim_product`, `dim_geography`, `dim_date` + the `fact_sales` grain (one row
per `SalesID`). Keys are TEXT (source uses codes like `O0000416`, `C00153`, `P00034`, `G001`).
The fact natural key is `(order_number, line_number)`; `sales_id` is the primary key. Control
tables: `etl_watermark` (incremental cursor), `etl_run_audit` (per-run counts + status). DDL:
[`sql/schema.sql`](sql/schema.sql).

Currency: each line keeps `currency` plus a normalized `amount_usd` via `decimal.Decimal`. The
source is single-currency (USD), so normalization is a documented pass-through; the rate map
(`USD/EUR/GBP/JPY`) is in `source_mapping.py` for multi-currency sources.

## DAG

`create_schema → extract_raw_documents → transform_documents → load_dimensions →
load_facts → validate_load`. `schedule=@daily`, `catchup=False`, `max_active_runs=1`,
retries=2, 10-min `execution_timeout`.

- **extract** — Mongo docs with `_id` above the stored cursor (incremental).
- **transform** — dedupe to latest batch, flatten `items[]`, normalize currency, map blank
  customer → `UNKNOWN`, **quarantine** bad rows (qty ≤ 0, missing field) with reasons.
- **load_facts** — per-order line sync + upsert (`ON CONFLICT … DO UPDATE`), audit, advance
  watermark in one transaction.
- **validate_load** — null / orphan-FK / audit-parity checks; raises on failure.

## Validation

`validate_load` enforces checks in-run; the same SQL is in
[`sql/validation_queries.sql`](sql/validation_queries.sql). Filled report:
[`docs/validation_report.md`](docs/validation_report.md); raw run output: `results/run_results.json`.

## MongoDB insight queries

14 aggregations (revenue/profit by category, region, segment, brand; top products/customers;
AOV; date range; data-quality probes) in [`mongo/insight_queries.js`](mongo/insight_queries.js).

## Outputs

`results/` contains the executed-run artifacts: `run_results.json`, the loaded warehouse tables
as CSV (`warehouse_tables/`), and result charts (`figures/`). `PROJECT_REPORT.docx` compiles
everything with the real numbers.

## Tests

```bash
python -m unittest tests/test_transform.py     # 9 tests: currency, flatten, quarantine, dedupe, UNKNOWN
python -m py_compile dags/*.py scripts/*.py
```

## Notes / tradeoffs

- Dimensions are SCD Type 1 (overwrite). XCom carries small payloads (stage at volume).
- Tasks read `MONGO_URI` / `WAREHOUSE_DSN` from env with credentials scrubbed from logs.
- `psycopg2-binary` for convenience; demo credentials are local-only.
