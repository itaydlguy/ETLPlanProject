// MongoDB source-profiling / insight queries for the raw_orders collection (nested sales
// orders built from the Power BI export). Run with:
//   mongosh "$MONGO_URI" mongo/insight_queries.js
// The raw layer is append-only, so queries first reduce to the latest version per order.

const db = db.getSiblingDB(process.env.MONGO_DB || "source");
const raw = db.raw_orders;
function show(t, c) { print("\n=== " + t + " ==="); printjson(c instanceof Array ? c : c.toArray()); }
const latest = [
  { $sort: { "order_number": 1, "_ingest.batch_seq": -1 } },
  { $group: { _id: "$order_number", doc: { $first: "$$ROOT" } } },
  { $replaceRoot: { newRoot: "$doc" } },
];

// 1. Raw document count (incl. superseded versions).
show("1. Raw document count", [{ count: raw.countDocuments({}) }]);

// 2. Distinct latest orders.
show("2. Distinct orders", raw.aggregate([...latest, { $count: "orders" }]));

// 3. Total line items.
show("3. Total line items", raw.aggregate([...latest,
  { $group: { _id: null, line_items: { $sum: { $size: "$items" } } } }]));

// 4. Revenue & profit by product category.
show("4. Revenue/profit by category", raw.aggregate([...latest, { $unwind: "$items" },
  { $group: { _id: "$items.category", revenue: { $sum: "$items.sales_amount" }, profit: { $sum: "$items.profit" } } },
  { $sort: { revenue: -1 } }]));

// 5. Top products by revenue.
show("5. Top products by revenue", raw.aggregate([...latest, { $unwind: "$items" },
  { $group: { _id: "$items.product_key", name: { $first: "$items.product_name" }, revenue: { $sum: "$items.sales_amount" } } },
  { $sort: { revenue: -1 } }, { $limit: 10 }]));

// 6. Top customers by spend.
show("6. Top customers by spend", raw.aggregate([...latest, { $unwind: "$items" },
  { $group: { _id: "$customer.customer_key", name: { $first: "$customer.name" }, spend: { $sum: "$items.sales_amount" } } },
  { $sort: { spend: -1 } }, { $limit: 10 }]));

// 7. Revenue by region.
show("7. Revenue by region", raw.aggregate([...latest, { $unwind: "$items" },
  { $group: { _id: "$geography.region", revenue: { $sum: "$items.sales_amount" } } },
  { $sort: { revenue: -1 } }]));

// 8. Revenue by customer segment.
show("8. Revenue by segment", raw.aggregate([...latest, { $unwind: "$items" },
  { $group: { _id: "$customer.segment", revenue: { $sum: "$items.sales_amount" } } },
  { $sort: { revenue: -1 } }]));

// 9. Revenue by brand.
show("9. Revenue by brand", raw.aggregate([...latest, { $unwind: "$items" },
  { $group: { _id: "$items.brand", revenue: { $sum: "$items.sales_amount" } } },
  { $sort: { revenue: -1 } }, { $limit: 10 }]));

// 10. Average order value.
show("10. Average order value", raw.aggregate([...latest,
  { $project: { total: { $sum: { $map: { input: "$items", as: "it", in: "$$it.sales_amount" } } } } },
  { $group: { _id: null, avg_order_value: { $avg: "$total" } } }]));

// 11. Order-date range.
show("11. Order date range", raw.aggregate([...latest,
  { $group: { _id: null, min_date: { $min: "$order_date" }, max_date: { $max: "$order_date" } } }]));

// 12. Line items per order distribution.
show("12. Line items per order", raw.aggregate([...latest,
  { $group: { _id: { $size: "$items" }, orders: { $sum: 1 } } }, { $sort: { _id: 1 } }]));

// 13. Data-quality: orders with a blank/UNKNOWN customer key.
show("13. Orders with missing customer", raw.aggregate([...latest,
  { $match: { $or: [{ "customer.customer_key": null }, { "customer.customer_key": "" }, { "customer.customer_key": "UNKNOWN" }] } },
  { $count: "orders_missing_customer" }]));

// 14. Data-quality: line items with non-positive quantity (quarantine candidates).
show("14. Line items with quantity <= 0", raw.aggregate([...latest, { $unwind: "$items" },
  { $match: { "items.quantity": { $lte: 0 } } },
  { $count: "non_positive_quantity_lines" }]));
