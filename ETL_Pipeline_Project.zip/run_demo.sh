#!/bin/sh
# One-command bring-up for the ETL stack (works on Play with Docker / any Docker host).
# Pre-built nested data is already in data/, so no Python is needed on the host.
set -e

echo ">> Building Airflow image (first time pulls ~1.5GB, be patient)..."
docker compose build

echo ">> Starting Postgres + Mongo + Airflow init..."
docker compose up -d postgres mongo airflow-init

echo ">> Waiting for databases to be healthy..."
for i in $(seq 1 30); do
  if docker compose ps | grep -q "healthy"; then break; fi
  sleep 3
done

echo ">> Starting Airflow scheduler + webserver..."
docker compose up -d airflow-scheduler airflow-webserver

echo ">> Seeding MongoDB with the real data (append-only)..."
docker compose run --rm mongo-seed --reset

cat <<'MSG'

============================================================
 STACK IS UP.
 1) In Play with Docker, click the "OPEN PORT" button, type 8080  -> Airflow UI
    (login: admin / admin). Un-pause and Trigger "mongo_to_postgres_etl".
    Watch the 6 tasks go green; open each task's Logs for the demo.

 OR trigger from the terminal:
    docker compose exec airflow-scheduler airflow dags trigger mongo_to_postgres_etl

 2) After it finishes, run the validation SQL (expect all 0s / parity true):
    docker compose exec postgres psql -U airflow -d warehouse -f /sql/validation_queries.sql

 3) Sample analytics:
    docker compose exec postgres psql -U airflow -d warehouse -c \
      "SELECT p.category, round(sum(f.amount_usd),2) revenue FROM fact_sales f \
       JOIN dim_product p ON p.product_key=f.product_key GROUP BY p.category ORDER BY revenue DESC;"
============================================================
MSG
