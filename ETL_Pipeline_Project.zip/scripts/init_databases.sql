-- Runs once, on first init of an empty Postgres data volume (docker-entrypoint-initdb.d).
-- Creates the `warehouse` target DB alongside the `airflow` metadata DB.
-- NOTE: if you change this later, it will NOT re-run on an existing volume - recreate the
-- `postgres-db` volume or apply manually. Warehouse TABLES are created idempotently by the
-- DAG's create_schema task (sql/schema.sql), not here.
SELECT 'CREATE DATABASE warehouse'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'warehouse')\gexec
