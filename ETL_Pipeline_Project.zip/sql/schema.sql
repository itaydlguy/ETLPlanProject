-- Warehouse sales star schema + ETL control tables.
-- Mirrors the Power BI model (FactSales + DimCustomer/DimProduct/DimGeography/DimDate),
-- cleaned for analytics. Applied idempotently by the DAG's create_schema task.
-- Keys are TEXT (source uses values like O0000416, C00153, P00034, G001).

CREATE TABLE IF NOT EXISTS dim_customer (
    customer_key TEXT PRIMARY KEY,   -- 'UNKNOWN' sentinel for blank source CustomerID
    name         TEXT,
    segment      TEXT,
    gender       TEXT,
    age          INTEGER,
    city         TEXT,
    country      TEXT
);

CREATE TABLE IF NOT EXISTS dim_product (
    product_key  TEXT PRIMARY KEY,
    product_name TEXT,
    category     TEXT,
    brand        TEXT
);

CREATE TABLE IF NOT EXISTS dim_geography (
    geography_key TEXT PRIMARY KEY,
    city          TEXT,
    region        TEXT,
    country       TEXT
);

CREATE TABLE IF NOT EXISTS dim_date (
    date_key  INTEGER PRIMARY KEY,   -- YYYYMMDD
    full_date DATE NOT NULL,
    year      INTEGER NOT NULL,
    quarter   INTEGER NOT NULL,
    month     INTEGER NOT NULL,
    day       INTEGER NOT NULL
);

-- Fact grain: one row per sales line (SalesID). Orders group lines via order_number.
CREATE TABLE IF NOT EXISTS fact_sales (
    sales_id      TEXT PRIMARY KEY,
    order_number  TEXT    NOT NULL,
    customer_key  TEXT    NOT NULL REFERENCES dim_customer(customer_key),
    product_key   TEXT    NOT NULL REFERENCES dim_product(product_key),
    geography_key TEXT             REFERENCES dim_geography(geography_key),
    order_date_key INTEGER NOT NULL REFERENCES dim_date(date_key),
    line_number   INTEGER NOT NULL,
    quantity      INTEGER NOT NULL,
    unit_price    NUMERIC(14,2) NOT NULL,
    discount      NUMERIC(14,2) NOT NULL DEFAULT 0,
    sales_amount  NUMERIC(14,2) NOT NULL,
    total_cost    NUMERIC(14,2) NOT NULL DEFAULT 0,
    profit        NUMERIC(14,2) NOT NULL DEFAULT 0,
    currency      TEXT    NOT NULL,
    amount_usd    NUMERIC(14,2) NOT NULL,
    CONSTRAINT uq_fact_sales_order_line UNIQUE (order_number, line_number)
);

CREATE INDEX IF NOT EXISTS ix_fact_sales_order ON fact_sales(order_number);
CREATE INDEX IF NOT EXISTS ix_fact_sales_product ON fact_sales(product_key);
CREATE INDEX IF NOT EXISTS ix_fact_sales_date ON fact_sales(order_date_key);

-- ETL control tables
CREATE TABLE IF NOT EXISTS etl_watermark (
    source_name    TEXT PRIMARY KEY,
    last_object_id TEXT,
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS etl_run_audit (
    run_id        TEXT PRIMARY KEY,
    source_orders INTEGER NOT NULL,
    source_items  INTEGER NOT NULL,
    loaded_orders INTEGER NOT NULL,
    loaded_items  INTEGER NOT NULL,
    status        TEXT    NOT NULL,
    error_detail  TEXT,
    run_ts        TIMESTAMPTZ NOT NULL DEFAULT now()
);
