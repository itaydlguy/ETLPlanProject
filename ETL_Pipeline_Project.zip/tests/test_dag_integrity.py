"""DAG-import integrity test. Requires Airflow + pymongo, so it is skipped where those
are not installed (e.g. a bare lint sandbox). Runs in the container / on a dev box with
the project requirements installed:

    pytest tests/test_dag_integrity.py
"""
import pathlib

import pytest

pytest.importorskip("airflow", reason="Airflow not installed in this environment")
pytest.importorskip("pymongo", reason="pymongo not installed in this environment")

DAGS_DIR = str(pathlib.Path(__file__).resolve().parents[1] / "dags")


def _dagbag():
    from airflow.models import DagBag

    return DagBag(dag_folder=DAGS_DIR, include_examples=False)


def test_no_import_errors():
    bag = _dagbag()
    assert bag.import_errors == {}, f"DAG import errors: {bag.import_errors}"


def test_single_expected_dag():
    bag = _dagbag()
    assert "mongo_to_postgres_etl" in bag.dags


def test_expected_tasks_and_dependencies():
    bag = _dagbag()
    dag = bag.dags["mongo_to_postgres_etl"]
    expected = {
        "create_schema", "extract_raw_documents", "transform_documents",
        "load_dimensions", "load_facts", "validate_load",
    }
    assert expected.issubset(set(dag.task_ids))
    # validate_load is terminal; create_schema is a root.
    assert dag.get_task("validate_load").downstream_task_ids == set()
    assert "load_facts" in dag.get_task("validate_load").upstream_task_ids
