#!/usr/bin/env python3
"""Seed MongoDB `raw_orders` from a Power BI-style dataset export.

Append-only landing zone: every run INSERTS documents (never replaces in place), stamping
each with `source_file`, `ingested_at`, and a run-level monotonic `batch_seq`. A re-sent
order therefore lands as a new document with a new `_id`/`batch_seq`; downstream the
transform keeps the latest `batch_seq` per `order_id`. This keeps raw history immutable and
lets the DAG's `_id` cursor reliably pick up new and updated orders.

Usage:
    python seed_mongo.py [--reset]
Env:
    MONGO_URI            mongodb connection string (required)
    MONGO_DB             database name (default: source)
    SOURCE_DATASET_PATH  path to JSON/CSV dataset (default: bundled sample_orders.json)
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import logging
import os
import sys
from pathlib import Path

from pymongo import MongoClient

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("seed_mongo")

DEFAULT_DATASET = "/opt/airflow/data/sample_orders.json"
RAW_COLLECTION = "raw_orders"


def _redact(uri: str) -> str:
    """Hide credentials before logging a connection string."""
    if "@" in uri and "//" in uri:
        scheme, rest = uri.split("//", 1)
        return f"{scheme}//***@{rest.split('@', 1)[1]}"
    return uri


def load_dataset(path: Path) -> list[dict]:
    """Read order documents from a JSON array or CSV. Fail loudly on anything else."""
    if not path.exists():
        raise FileNotFoundError(f"SOURCE_DATASET_PATH does not exist: {path}")
    suffix = path.suffix.lower()
    if suffix == ".json":
        with path.open(encoding="utf-8") as fh:
            data = json.load(fh)
        if not isinstance(data, list):
            raise ValueError("JSON dataset must be a top-level array of order documents")
        return data
    if suffix == ".csv":
        # Deferred: a real Power BI CSV export is flat and needs order/item regrouping.
        raise NotImplementedError(
            "CSV ingestion is intentionally not implemented for the bundled demo. "
            "Provide a JSON export or extend load_dataset() for your CSV shape."
        )
    raise ValueError(f"Unsupported dataset extension: {suffix} (use .json)")


def next_batch_seq(collection) -> int:
    """Run-level monotonic sequence: max existing batch_seq + 1 (1 on empty collection)."""
    doc = collection.find_one(sort=[("batch_seq", -1)], projection={"batch_seq": 1})
    return int(doc["batch_seq"]) + 1 if doc and "batch_seq" in doc else 1


def seed(reset: bool = False) -> int:
    mongo_uri = os.environ.get("MONGO_URI")
    if not mongo_uri:
        raise RuntimeError("MONGO_URI is not set")
    db_name = os.environ.get("MONGO_DB", "source")
    dataset_path = Path(os.environ.get("SOURCE_DATASET_PATH", DEFAULT_DATASET))

    log.info("Connecting to Mongo at %s (db=%s)", _redact(mongo_uri), db_name)
    client = MongoClient(mongo_uri, serverSelectionTimeoutMS=10000)
    collection = client[db_name][RAW_COLLECTION]

    if reset:
        log.warning("--reset: dropping collection %s", RAW_COLLECTION)
        collection.drop()

    orders = load_dataset(dataset_path)
    batch_seq = next_batch_seq(collection)
    ingested_at = dt.datetime.now(dt.timezone.utc)

    docs = []
    for order in orders:
        if not order.get("order_id"):
            raise ValueError(f"Order document missing order_id: {order!r}")
        enriched = dict(order)
        enriched["_ingest"] = {
            "source_file": dataset_path.name,
            "ingested_at": ingested_at,
            "batch_seq": batch_seq,
        }
        docs.append(enriched)

    result = collection.insert_many(docs)
    log.info(
        "Inserted %d documents into %s (batch_seq=%d) from %s",
        len(result.inserted_ids), RAW_COLLECTION, batch_seq, dataset_path.name,
    )
    return len(result.inserted_ids)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Seed MongoDB raw_orders (append-only).")
    parser.add_argument("--reset", action="store_true",
                        help="Drop raw_orders before seeding (clean demo only).")
    args = parser.parse_args(argv)
    seed(reset=args.reset)
    return 0


if __name__ == "__main__":
    sys.exit(main())
