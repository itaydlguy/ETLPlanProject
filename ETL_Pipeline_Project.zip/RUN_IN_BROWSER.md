# Run the live stack in your browser — no install, no admin

Play with Docker is shut down. Use one of these free options instead. **GitHub Codespaces**
is recommended (more memory — Airflow is heavy). Google Cloud Shell is a lighter fallback.

You only need the file **ETL_Pipeline_Project.zip** (in your ETLPlanProject folder).

---

## Option A — GitHub Codespaces (recommended)

1. Create a free account at https://github.com (skip if you have one).
2. Click **+** (top-right) → **New repository**. Name it `etl`, tick **Add a README**, **Create**.
3. On the repo page: **Add file ▾ → Upload files**. Drag **ETL_Pipeline_Project.zip** in,
   then **Commit changes**.
4. Click the green **Code ▾** button → **Codespaces** tab → **Create codespace on main**.
   Wait ~1 min for the browser editor to open.
5. In the **Terminal** at the bottom, paste:
   ```sh
   unzip -o ETL_Pipeline_Project.zip -d etl && cd etl
   bash run_demo.sh
   ```
   (First build pulls ~1.5 GB — a few minutes.)
6. When it's up, click the **Ports** tab → find port **8080** → click the 🌐 globe to open the
   **Airflow UI** (login `admin` / `admin`). Un-pause and **Trigger** `mongo_to_postgres_etl`;
   watch the 6 tasks go green; open a task's **Logs** to narrate.
7. Validate (expect 0s / parity true):
   ```sh
   docker compose exec postgres psql -U airflow -d warehouse -f /sql/validation_queries.sql
   ```
8. Take screenshots of the green DAG + validation output for your submission.
   When done, delete the Codespace (github.com/codespaces) so it stops using free hours.

If `docker` says "command not found" in the Codespace, use Option B instead.

---

## Option B — Google Cloud Shell (lighter, simple upload)

1. Go to https://shell.cloud.google.com and sign in with a Google account. Click **Continue**.
2. Top-right of the shell: **⋮ (More) → Upload → File** → choose **ETL_Pipeline_Project.zip**.
3. In the terminal:
   ```sh
   unzip -o ETL_Pipeline_Project.zip -d etl && cd etl
   bash run_demo.sh
   ```
4. Trigger the DAG from the terminal (Cloud Shell web preview is fiddly):
   ```sh
   docker compose exec airflow-scheduler airflow dags trigger mongo_to_postgres_etl
   # check status:
   docker compose exec airflow-scheduler airflow dags list-runs -d mongo_to_postgres_etl
   ```
   For the UI: click **Web Preview** (top-right) → **Change port** → 8080.
5. Validate:
   ```sh
   docker compose exec postgres psql -U airflow -d warehouse -f /sql/validation_queries.sql
   ```
   Note: Cloud Shell has limited RAM; if a container gets killed, prefer Option A.

---

## Expected numbers (match the report)
- 12,094 fact rows, 7,193 distinct orders, 24 rows quarantined (quantity = 0).
- Revenue ≈ USD 23,541,083.85, profit ≈ USD 8,202,065.08.

## If anything errors
Copy the red message here and I'll give you the exact one-line fix.
