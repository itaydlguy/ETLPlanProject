# Run everything automatically on GitHub (no PC, no Docker install)

GitHub runs the whole stack on its own servers and saves proof you can download.

## If you already have a Git repo with this project
1. Make sure the file `.github/workflows/etl-ci.yml` is at the **repo root** (it ships in
   this project). Commit & push it.
2. Open the repo on github.com → **Actions** tab → watch the run "ETL pipeline (real stack)".
3. When it's green, open the run → **Artifacts → etl-proof** → download. It contains:
   `validation_output.txt` (all 0s / parity true), `etl_run_audit.txt`, `mongo_output.txt`.

## If you don't have a repo yet (easiest, upload the zip)
1. github.com → **+ → New repository** → name `etl`, tick "Add a README", **Create**.
2. **Add file → Create new file** → filename: `.github/workflows/etl-ci.yml` →
   paste the contents of that file (open it from this project) → **Commit**.
3. **Add file → Upload files** → drag **ETL_Pipeline_Project.zip** → **Commit**.
   (The workflow unzips it automatically.)
4. **Actions** tab → the run starts on its own → green ✓ → download the **etl-proof** artifact.

That's the live run on real Postgres + real Mongo + the real Airflow DAG, executed in
GitHub's cloud. Free for public repos (private: 2000 min/month free).

If a run goes red, open it, copy the failing step's log here, and I'll fix it.
