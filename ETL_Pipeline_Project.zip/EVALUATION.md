# Evaluation & Verification Report

**Method.** The *delivered* project files were copied to a clean location, compiled, unit-tested,
and re-run end-to-end on the **real** Power BI data. The re-run reproduced the shipped results
exactly, so the numbers below are verified, not asserted.

```
Verification re-run vs shipped results:
  fact rows after delta      12,094 == 12,094   ✅
  distinct orders             7,193 ==  7,193   ✅
  rejected (qty=0)               24 ==     24   ✅
  idempotency replay rows         0 ==      0   ✅
  run 1 validation            PASS == PASS      ✅
  run 2 validation            PASS == PASS      ✅
  total revenue (USD)  23,541,083.85 == 23,541,083.85  ✅
  py_compile (all .py)        OK     |  unit tests 9/9 OK
```

## Real data confirmed

Source = exported tables from `PowerBI_Project.pbix`: **12,118 sales lines / 7,200 orders,
800 customers, 306 products, 30 geographies, 2021–2024**. Not synthetic.

## Task checklist (task doc 01–08)

| # | Task | Status | Evidence |
|---|------|--------|----------|
| 01 | Docker Compose: Mongo + Airflow + Postgres on a shared network | ✅ | `docker-compose.yml` (5 services, healthchecks, volumes, network) |
| 02 | Seed MongoDB with the dataset | ✅ | `scripts/csv_to_orders.py` + `scripts/seed_mongo.py` (append-only) |
| 03 | PostgreSQL target schema with PK/FK | ✅ | `sql/schema.sql` (star, PK/FK, fact UNIQUE, control tables) |
| 04 | Airflow DAG with E/T/L tasks + dependencies | ✅ | `dags/mongo_to_postgres_etl.py` (6 tasks, TaskFlow) |
| 05 | Transformations: flatten, normalize currency, handle nulls | ✅ | `dags/etl_core.py` (flatten, Decimal FX, UNKNOWN, quarantine) |
| 07 | Error handling, retries, task-level logging | ✅ | `default_args` retries+timeout; per-task logging; validate raises |
| 08 | SQL validation queries (row counts + integrity) | ✅ | `sql/validation_queries.sql` + enforced `validate_load` |

(The task doc skips 06; numbering preserved.)

## Deliverables (1–5)

| # | Deliverable | Status | Evidence |
|---|-------------|--------|----------|
| 1 | 10+ MongoDB insight queries | ✅ | `mongo/insight_queries.js` — 14 aggregations |
| 2 | ERD with PK/FK/types + star-vs-snowflake rationale | ✅ | `docs/diagrams.md` |
| 3 | DAG documentation (flow, task responsibilities, schedule rationale) | ✅ | `docs/diagrams.md` + `PROJECT_REPORT.docx` §5 |
| 4 | Validation report (row-count match, null checks, orphan FKs=0) | ✅ | `docs/validation_report.md`, `results/run_results.json` |
| 5 | Live demo (trigger, walk task logs, analytics query) | ✅ (scripted) | README 15-min demo script; analytics in report §8 |

## Rubric coverage

| Component | Weight | Covered by |
|-----------|--------|-----------|
| DAG Design & Orchestration | 30% | 6-task DAG, deps, @daily, retries, timeout, logging, max_active_runs=1 |
| Transformations & Data Quality | 15% | flatten, Decimal currency, UNKNOWN nulls, 24 quarantined, 9 unit tests |
| MongoDB Insight Queries | 10% | 14 aggregations |
| PostgreSQL Schema Design | 20% | star schema, PK/FK, fact UNIQUE constraint, ERD |
| Incremental Load Logic | 15% | watermark cursor + ON CONFLICT upsert + per-order sync; replay added 0 rows |
| Documentation & Demo | 10% | README, diagrams, PROJECT_REPORT.docx, this evaluation |

## Data quality (handled and reported)

- 24 source rows with quantity = 0 → **quarantined** with reasons (`reject_samples` in run_results.json).
- 71 fact rows with blank `CustomerID` → mapped to an `UNKNOWN` customer dimension member.
- 7 single-line orders fully quarantined → distinct orders 7,200 → 7,193.

## Honest limitations

1. **Execution substrate.** The ETL *logic* was executed in a local SQLite warehouse (reliable,
   no external services). The identical code targets PostgreSQL via the Airflow DAG under Docker;
   starting the container stack and the live `DagBag` import are the operator's step on a
   Docker-capable host (none is available in this build environment). `tests/test_dag_integrity.py`
   covers the DAG import and auto-skips where Airflow isn't installed.
2. **Source extraction.** The `.pbix` model is XPress9-compressed and could not be read directly
   here; the five tables were exported to CSV from Power BI and used as the real source.
3. **Currency.** The source is single-currency (USD); normalization is implemented but is a
   documented pass-through.
