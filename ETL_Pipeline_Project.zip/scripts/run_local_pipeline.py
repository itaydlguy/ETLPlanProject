#!/usr/bin/env python3
"""Local end-to-end execution of the ETL logic without Docker/Mongo/Postgres.

Runs extract (read JSON) -> transform (etl_core) -> load (SQLite warehouse with the same
upsert/sync/audit semantics as the Airflow DAG) -> validate -> analytics. Executes an
initial load, an incremental delta, and an idempotency replay; quarantined rows reported.

Usage:
    python run_local_pipeline.py --data-dir data --out-dir results
Expects data/orders_initial.json and data/orders_delta.json (built by csv_to_orders.py).
"""
from __future__ import annotations

import argparse
import csv
import json
import pathlib
import sqlite3
import sys
from collections import defaultdict
from decimal import Decimal

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "dags"))
from etl_core import transform  # noqa: E402

DDL = """
CREATE TABLE dim_customer (customer_key TEXT PRIMARY KEY, name TEXT, segment TEXT, gender TEXT, age INTEGER, city TEXT, country TEXT);
CREATE TABLE dim_product (product_key TEXT PRIMARY KEY, product_name TEXT, category TEXT, brand TEXT);
CREATE TABLE dim_geography (geography_key TEXT PRIMARY KEY, city TEXT, region TEXT, country TEXT);
CREATE TABLE dim_date (date_key INTEGER PRIMARY KEY, full_date TEXT, year INT, quarter INT, month INT, day INT);
CREATE TABLE fact_sales (sales_id TEXT PRIMARY KEY, order_number TEXT NOT NULL,
 customer_key TEXT NOT NULL REFERENCES dim_customer(customer_key),
 product_key TEXT NOT NULL REFERENCES dim_product(product_key),
 geography_key TEXT REFERENCES dim_geography(geography_key),
 order_date_key INTEGER NOT NULL REFERENCES dim_date(date_key),
 line_number INT, quantity INT, unit_price REAL, discount REAL, sales_amount REAL,
 total_cost REAL, profit REAL, currency TEXT, amount_usd REAL, UNIQUE(order_number,line_number));
CREATE TABLE etl_run_audit (run_id TEXT PRIMARY KEY, source_orders INT, source_items INT, loaded_orders INT, loaded_items INT, status TEXT, error_detail TEXT, run_ts TEXT);
"""


def _f(d):
    return float(d) if isinstance(d, Decimal) else d


def load(conn, result, run_id):
    cur = conn.cursor()
    for c in result.customers.values():
        cur.execute("INSERT INTO dim_customer VALUES (:customer_key,:name,:segment,:gender,:age,:city,:country) ON CONFLICT(customer_key) DO UPDATE SET name=excluded.name,segment=excluded.segment,gender=excluded.gender,age=excluded.age,city=excluded.city,country=excluded.country", c)
    for p in result.products.values():
        cur.execute("INSERT INTO dim_product VALUES (:product_key,:product_name,:category,:brand) ON CONFLICT(product_key) DO UPDATE SET product_name=excluded.product_name,category=excluded.category,brand=excluded.brand", p)
    for g in result.geographies.values():
        cur.execute("INSERT INTO dim_geography VALUES (:geography_key,:city,:region,:country) ON CONFLICT(geography_key) DO UPDATE SET city=excluded.city,region=excluded.region,country=excluded.country", g)
    for d in result.dates.values():
        cur.execute("INSERT INTO dim_date VALUES (:date_key,:full_date,:year,:quarter,:month,:day) ON CONFLICT(date_key) DO NOTHING", d)
    lbo = defaultdict(list)
    for f in result.facts:
        lbo[f["order_number"]].append(f["line_number"])
    for on, lns in lbo.items():
        q = ",".join("?" * len(lns))
        cur.execute("DELETE FROM fact_sales WHERE order_number=? AND line_number NOT IN (" + q + ")", [on, *lns])
    for f in result.facts:
        row = {k: _f(v) for k, v in f.items()}
        cur.execute("INSERT INTO fact_sales VALUES (:sales_id,:order_number,:customer_key,:product_key,:geography_key,:order_date_key,:line_number,:quantity,:unit_price,:discount,:sales_amount,:total_cost,:profit,:currency,:amount_usd) ON CONFLICT(sales_id) DO UPDATE SET order_number=excluded.order_number,customer_key=excluded.customer_key,product_key=excluded.product_key,geography_key=excluded.geography_key,order_date_key=excluded.order_date_key,line_number=excluded.line_number,quantity=excluded.quantity,unit_price=excluded.unit_price,discount=excluded.discount,sales_amount=excluded.sales_amount,total_cost=excluded.total_cost,profit=excluded.profit,currency=excluded.currency,amount_usd=excluded.amount_usd", row)
    cur.execute("INSERT INTO etl_run_audit VALUES (?,?,?,?,?,'success',NULL,datetime('now')) ON CONFLICT(run_id) DO UPDATE SET source_orders=excluded.source_orders,source_items=excluded.source_items,loaded_orders=excluded.loaded_orders,loaded_items=excluded.loaded_items",
                (run_id, result.source_orders, result.source_items, len(lbo), len(result.facts)))
    conn.commit()


def validate(conn, run_id):
    cur = conn.cursor()
    ch = {}
    cur.execute("SELECT count(*) FROM fact_sales WHERE order_number IS NULL OR product_key IS NULL OR customer_key IS NULL OR quantity IS NULL OR sales_amount IS NULL OR amount_usd IS NULL OR order_date_key IS NULL")
    ch["null_required_fields"] = cur.fetchone()[0]
    for label, join in {
        "orphan_product": "LEFT JOIN dim_product d ON d.product_key=f.product_key WHERE d.product_key IS NULL",
        "orphan_customer": "LEFT JOIN dim_customer d ON d.customer_key=f.customer_key WHERE d.customer_key IS NULL",
        "orphan_date": "LEFT JOIN dim_date d ON d.date_key=f.order_date_key WHERE d.date_key IS NULL",
        "orphan_geography": "LEFT JOIN dim_geography d ON d.geography_key=f.geography_key WHERE f.geography_key IS NOT NULL AND d.geography_key IS NULL",
    }.items():
        cur.execute("SELECT count(*) FROM fact_sales f " + join)
        ch[label] = cur.fetchone()[0]
    cur.execute("SELECT count(*) FROM fact_sales WHERE quantity<=0 OR sales_amount<0")
    ch["non_positive_qty_or_amount"] = cur.fetchone()[0]
    cur.execute("SELECT source_orders,loaded_orders,source_items,loaded_items FROM etl_run_audit WHERE run_id=?", (run_id,))
    a = cur.fetchone()
    ch["audit_parity_ok"] = bool(a and a[0] == a[1] and a[2] == a[3])
    ch["_passed"] = all(ch[k] == 0 for k in ("null_required_fields", "orphan_product", "orphan_customer", "orphan_date", "orphan_geography", "non_positive_qty_or_amount")) and ch["audit_parity_ok"]
    return ch


def counts(conn):
    cur = conn.cursor()
    out = {}
    for t in ("dim_customer", "dim_product", "dim_geography", "dim_date", "fact_sales"):
        cur.execute("SELECT count(*) FROM " + t)
        out[t] = cur.fetchone()[0]
    cur.execute("SELECT count(DISTINCT order_number) FROM fact_sales")
    out["distinct_orders"] = cur.fetchone()[0]
    cur.execute("SELECT count(*) FROM fact_sales WHERE customer_key='UNKNOWN'")
    out["unknown_customer_rows"] = cur.fetchone()[0]
    return out


def analytics(conn):
    cur = conn.cursor()
    r = {}
    cur.execute("SELECT p.category,ROUND(SUM(f.amount_usd),2),ROUND(SUM(f.profit),2),SUM(f.quantity) FROM fact_sales f JOIN dim_product p ON p.product_key=f.product_key GROUP BY p.category ORDER BY 2 DESC")
    r["revenue_profit_by_category"] = cur.fetchall()
    cur.execute("SELECT g.region,ROUND(SUM(f.amount_usd),2) FROM fact_sales f JOIN dim_geography g ON g.geography_key=f.geography_key GROUP BY g.region ORDER BY 2 DESC")
    r["revenue_by_region"] = cur.fetchall()
    cur.execute("SELECT c.segment,ROUND(SUM(f.amount_usd),2) FROM fact_sales f JOIN dim_customer c ON c.customer_key=f.customer_key GROUP BY c.segment ORDER BY 2 DESC")
    r["revenue_by_segment"] = cur.fetchall()
    cur.execute("SELECT d.year,ROUND(SUM(f.amount_usd),2),ROUND(SUM(f.profit),2) FROM fact_sales f JOIN dim_date d ON d.date_key=f.order_date_key GROUP BY d.year ORDER BY d.year")
    r["revenue_by_year"] = cur.fetchall()
    cur.execute("SELECT p.product_name,ROUND(SUM(f.amount_usd),2) rev,SUM(f.quantity) u FROM fact_sales f JOIN dim_product p ON p.product_key=f.product_key GROUP BY p.product_name ORDER BY rev DESC LIMIT 10")
    r["top_products"] = cur.fetchall()
    cur.execute("SELECT c.name,ROUND(SUM(f.amount_usd),2) s FROM fact_sales f JOIN dim_customer c ON c.customer_key=f.customer_key WHERE c.customer_key<>'UNKNOWN' GROUP BY c.name ORDER BY s DESC LIMIT 10")
    r["top_customers"] = cur.fetchall()
    cur.execute("SELECT ROUND(SUM(amount_usd),2),ROUND(SUM(profit),2),ROUND(SUM(profit)*100.0/SUM(amount_usd),2) FROM fact_sales")
    t = cur.fetchone()
    r["totals"] = {"total_revenue_usd": t[0], "total_profit_usd": t[1], "profit_margin_pct": t[2]}
    return r


def dump_tables(conn, out_dir):
    td = out_dir / "warehouse_tables"
    td.mkdir(parents=True, exist_ok=True)
    cur = conn.cursor()
    for t in ("dim_customer", "dim_product", "dim_geography", "dim_date", "fact_sales", "etl_run_audit"):
        cur.execute("SELECT * FROM " + t)
        cols = [c[0] for c in cur.description]
        w = csv.writer(open(td / (t + ".csv"), "w", newline="", encoding="utf-8"))
        w.writerow(cols)
        w.writerows(cur.fetchall())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", required=True)
    ap.add_argument("--out-dir", required=True)
    a = ap.parse_args()
    data = pathlib.Path(a.data_dir)
    out = pathlib.Path(a.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    initial = json.load(open(data / "orders_initial.json"))
    delta = json.load(open(data / "orders_delta.json"))
    conn = sqlite3.connect(":memory:")
    conn.executescript(DDL)
    rep = {"runs": []}

    r1 = transform(initial)
    load(conn, r1, "run-1-initial")
    rep["runs"].append({"run_id": "run-1-initial", "audit": {"source_orders": r1.source_orders, "source_items": r1.source_items, "loaded_orders": len({f['order_number'] for f in r1.facts}), "loaded_items": len(r1.facts), "rejected_items": len(r1.rejects)}, "validation": validate(conn, "run-1-initial"), "warehouse_counts": counts(conn)})

    r2 = transform(delta)
    load(conn, r2, "run-2-delta")
    rep["runs"].append({"run_id": "run-2-delta", "audit": {"source_orders": r2.source_orders, "source_items": r2.source_items, "loaded_orders": len({f['order_number'] for f in r2.facts}), "loaded_items": len(r2.facts), "rejected_items": len(r2.rejects)}, "validation": validate(conn, "run-2-delta"), "warehouse_counts": counts(conn)})

    before = counts(conn)["fact_sales"]
    load(conn, transform(initial), "run-3-replay")
    after = counts(conn)["fact_sales"]
    rep["idempotency_replay"] = {"fact_rows_before": before, "fact_rows_after": after, "rows_added": after - before}
    rep["total_rejected"] = len(r1.rejects) + len(r2.rejects)
    rep["reject_samples"] = (r1.rejects + r2.rejects)[:10]
    rep["analytics"] = analytics(conn)
    dump_tables(conn, out)
    json.dump(rep, open(out / "run_results.json", "w"), indent=2)
    print(json.dumps({k: v for k, v in rep.items() if k != "analytics"}, indent=2))


if __name__ == "__main__":
    main()
