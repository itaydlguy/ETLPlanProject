# Diagrams

## Architecture

```mermaid
flowchart LR
    pbix["Power BI export (5 CSVs)"] --> conv["csv_to_orders.py (nest by OrderID)"]
    conv --> ordersJson["nested orders JSON"]
    ordersJson --> seed["seed_mongo.py (append-only)"]
    seed --> mongo[(MongoDB raw_orders)]
    mongo --> extract["extract_raw_documents (_id cursor)"]
    extract --> transform["transform_documents (flatten + quarantine)"]
    transform --> loadDim["load_dimensions"]
    loadDim --> loadFact["load_facts (+sync, audit, watermark)"]
    loadFact --> pg[(PostgreSQL sales star)]
    pg --> validate["validate_load (enforced)"]
```

## DAG flow

```mermaid
flowchart TD
    createSchema["create_schema"] --> extract["extract_raw_documents"]
    extract --> transform["transform_documents"]
    transform --> loadDims["load_dimensions"]
    loadDims --> loadFacts["load_facts"]
    loadFacts --> validate["validate_load"]
```

## ERD (warehouse sales star)

```mermaid
erDiagram
    dim_customer  ||--o{ fact_sales : buys
    dim_product   ||--o{ fact_sales : sold
    dim_geography ||--o{ fact_sales : shipped_to
    dim_date      ||--o{ fact_sales : dated

    dim_customer { text customer_key PK
        text name
        text segment
        text gender
        int  age
        text city
        text country }
    dim_product { text product_key PK
        text product_name
        text category
        text brand }
    dim_geography { text geography_key PK
        text city
        text region
        text country }
    dim_date { int date_key PK
        date full_date
        int year
        int quarter
        int month
        int day }
    fact_sales { text sales_id PK
        text order_number
        text customer_key FK
        text product_key FK
        text geography_key FK
        int order_date_key FK
        int line_number
        int quantity
        numeric unit_price
        numeric discount
        numeric sales_amount
        numeric total_cost
        numeric profit
        text currency
        numeric amount_usd }
```

Star (not snowflake): the four dimensions attach directly to `fact_sales` with single-hop
joins, keeping the revenue/profit-by-category/region/segment/year analytics flat. The fact
grain is one row per `SalesID`; orders are groups of lines sharing `order_number`.
