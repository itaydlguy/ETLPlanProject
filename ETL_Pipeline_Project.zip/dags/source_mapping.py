from __future__ import annotations
from decimal import Decimal
CSV_FILES = {"fact_sales":"fact_sales.csv","dim_customer":"DimCustomer.csv","dim_product":"DimProduct.csv","dim_geography":"DimGeography.csv","dim_date":"DimDate.csv"}
FACT = {"sales_id":"SalesID","order_number":"OrderID","customer_key":"CustomerID","product_key":"ProductID","geography_key":"GeoID","year":"Year","month":"Month","day":"Day","quantity":"Sum of Quantity","unit_price":"Sum of UnitPrice","revenue":"Sum of Revenue","profit":"Sum of Profit","discount":"Sum of Discount"}
DIM_CUSTOMER = {"customer_key":"CustomerID","name":"CustomerName","segment":"Segment","gender":"Gender","age":"Age","city":"City","country":"Country"}
DIM_PRODUCT = {"product_key":"ProductID","product_name":"ProductName","category":"Category","brand":"Brand","unit_cost":"Sum of Cost","list_price":"Sum of Price"}
DIM_GEOGRAPHY = {"geography_key":"GeoID","city":"City","region":"Region","country":"Country"}
DIM_DATE = {"full_date":"Date","month_name":"MonthName","month_no":"Sum of MonthNo"}
UNKNOWN_KEY = "UNKNOWN"
MONTHS = {m:i for i,m in enumerate(["January","February","March","April","May","June","July","August","September","October","November","December"],start=1)}
def month_to_num(name):
    n=(name or "").strip()
    if n in MONTHS: return MONTHS[n]
    abbr={k[:3]:k for k in MONTHS}
    if n[:3].title() in abbr: return MONTHS[abbr[n[:3].title()]]
    raise ValueError("Unrecognized month: "+repr(name))
BASE_CURRENCY="USD"
FX_RATES={"USD":Decimal("1.00"),"EUR":Decimal("1.08"),"GBP":Decimal("1.27"),"JPY":Decimal("0.0067")}
